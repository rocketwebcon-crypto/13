// EditableImage feature removed — provide a no-op image fallback.
import React from 'react';

type Props = {
  src: string;
  alt?: string;
  className?: string;
  wrapperClassName?: string;
  loading?: 'eager' | 'lazy';
  fetchPriority?: string;
};

const EditableImage: React.FC<Props> = ({ src, alt = '', className, wrapperClassName }) => {
  return (
    <div className={wrapperClassName}>
      <img src={src} alt={alt} className={className} draggable={false} />
    </div>
  );
};

export default EditableImage;
